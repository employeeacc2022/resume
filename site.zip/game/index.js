function openGameHorse(){
    window.location.href = './horse/index.html';
}

function openGameBird(){
    window.location.href = './bird/index.html';
}

function openGameFood(){
    window.location.href = './food/index.html';
}

