function openGamePage(){
    window.location.href = './game/index.html';
}

function openMapPage(){
    window.location.href = './map/index.html';
}

function openFlexPage(){
    window.location.href = './flexbox/index.html';
}

function openResumePage(){
    window.location.href = './resume.html';
}

function openLetterPage(){
    window.location.href = './letter.html';
}

function openMysqlPage(){
    window.location.href = './mysql/index.php';
}